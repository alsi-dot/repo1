function setup() {
  createCanvas(300, 300);
  background(10);
}

function draw() {
  colorMode(RGB, 255,255,255,1);
  fill(130,160,230);
  stroke(110,140,180,0.5);
  strokeWeight(2);
  //ship
  triangle(20,40,50,60,80,20);
  fill(140,180,250);
  quad(20,40,50,50,80,20,40,30);
  strokeWeight(4);
  arc(90,230,10,10,10,PI+QUARTER_PI,PIE);
  //stars
  strokeWeight(2);
  stroke(250,250,250);
  point(100,80);
  point(200,150);
  point(24,240);
  strokeWeight(3);
  point(90,200);
  strokeWeight(4);
  point(160,25);
  point(250,252);
  //planets
  stroke(135,230,37,0.2);
  strokeWeight(3);
  fill(160,250,80);
  ellipse(120,270,30); 
  stroke(135,20,200,0.3);
  fill(170,25,240);
  ellipse(248,90,62);
  stroke(70,5,110);
  strokeWeight(5);
  noFill();
  beginShape();
  curveVertex(240,270);
  curveVertex(200,90);
  curveVertex(290,100);
  curveVertex(320,5);
  endShape();
  fill(250,10,50);
  stroke(253,130,195,0.8);
  ellipse(270,205,15);
}