var len = 10;
var wid = 10;
function setup() {
  createCanvas(600, 400);
  colorMode(RGB,255,255,255,1);
  angleMode(DEGREES);
}

function draw() {
  background(50);
  
  
  
  var x = 0;
  var y = 0;
  
  //aliens covering the top of the canvas
  scale(0.3);
  for(var i = 0;i<1920;i+=120){
    var r = 0;
    for(var j = 0;j<700;j+=110){
      alien(i,j,r);
      r+=90;
      if(r===180){
        r=0;
      }
      //grab the rows
      y++;
    } 
    //grab the columns
    x++;
    print(numAlien(x,y));
    //stops x from repeating each time inflating # given
    x=0;
  }
  ship(900,1000);
}

function numAlien(i,j){
  var num = i*j;
  return num;
}

function alien(x,y,r){
  push();
  translate(x,y);
  noStroke();
  fill(100,255,100);
  rotate(r);
  
  rect(50,50,len,wid);
  rect(60,60,len,wid);
  rect(130,50,len,wid);
  rect(120,60,len,wid);
  rect(70,70,len*5,wid);
  rect(60,80,len*7,wid);
  rect(50,90,len*2,wid);
  rect(80,90,len*3,wid);
  rect(120,90,len*2,wid);
  rect(40,100,len*11,wid);
  rect(40,110,len,wid*2);
  rect(140,110,len,wid*2);
  rect(60,110,len,wid*2);
  rect(120,110,len,wid*2);
  rect(70,110,len*5,wid);
  rect(70,130,len*2,wid);
  rect(100,130,len*2,wid);
  
  pop();
}
function ship(x,y){
  translate(x,y);
  noStroke();
  fill(255);
  rect(70,0,len,wid*3);
  rect(60,30,len*3,wid*3);
  
  fill(50,50,255);
  rect(30,70,len*2,wid*2);
  rect(100,70,len*2,wid*2);
  
  fill(255);
  rect(50,60,len*5,wid*2);
  
  fill(255,50,50);
  rect(90,110,len*2,wid*3);
  rect(40,110,len*2,wid*3);
  
  fill(255);
  rect(30,60,len,wid*2);
  rect(110,60,len,wid*2);
  rect(40,80,len*7,wid*3);
  rect(30,90,len*9,wid*2);
  rect(20,100,len*3,wid*2);
  rect(100,100,len*3,wid*2);
  rect(0,80,len,wid*7);
  rect(140,80,len,wid*7);
  rect(130,110,len,wid*3);
  rect(10,110,len,wid*3);
  rect(20,120,len,wid);
  rect(120,120,len,wid);
  rect(60,110,len*3,wid*2);
  rect(70,130,len,wid*2);
  
  fill(255,50,50);
  rect(70,70,len,wid*2);
  rect(60,80,len,wid*2);
  rect(80,80,len,wid*2);
  rect(30,40,len,wid*2);
  rect(110,40,len,wid*2);
  rect(0,60,len,wid*2);
  rect(140,60,len,wid*2);
}

//Design a composition that is within the theme of either Weather or a Retro Games. (10%)
//Create a function that draws a shape made from other shapes, lines, and/or dots. Position this function on the Canvas by calling the function and passing unique x and y coordinates to the function, using those coordinates to move the results of the function using the translate()Links to an external site. function. (10%)

//Create multiple copies of the function from the the previous requirement using a for() loop. For loops were part of Assignment Four (10%)

//Use the scale()Links to an external site. method in your assignment code to update the drawing of the function. (10%)

//Use the rotate()Links to an external site. method in your assignment code to  update the drawing of the function. (10%) 

//Set the angleMode()Links to an external site. in your code to determine the type of measurement used to determine the angle of rotation in the prior requirement. (10%)

//Use the push()Links to an external site. and pop()Links to an external site. functions in your assignment code. (10%)

//Create a function that returns a value and sends this information to the console by using the print()Links to an external site. function. (10%)