let x = 150;
let y = 300;
let rad = 50;
let X = 400;
let Y1 = 85;
let Y2 = 450;
let w = 95;
let h = 80;

function setup() {
  createCanvas(600, 600);
  ellipseMode(RADIUS);
  colorMode(RGB,255,255,255,1);
  strokeJoin(ROUND);
  strokeWeight(3);
  textSize(40);
}

function draw() {
  background(120);
  
  //top right box
  if((mouseX>X)&&(mouseX<X+w)&&(mouseY>Y1)&&(mouseY <Y1+h)){
    fill(255,155,155);
    stroke(200,100,100);
  }
  else{
    fill(200,100,100);
    stroke(150,50,50,0.5);
  }
  rect(X,Y1,w,h);
  
  //bottom right box
  if((mouseX>X)&&(mouseX<X+w)&&(mouseY>Y2)&&(mouseY <Y2+h)){
    fill(155,255,155);
    stroke(100,200,100,0.5);
  }
  else{
    fill(100,200,100);
    stroke(50,150,50,0.5);
  }
  rect(X,Y2,w,h);
  
  //left circle
  var d = dist(mouseX,mouseY,x,y);
  if(d<rad){
    fill(155,155,255);
    stroke(100,100,200,0.5);
    if(mouseIsPressed==true){
      rad++;
    }
  }
  else{
    fill(100,100,200);
    stroke(50,50,150,0.5);
  }
  ellipse(x,y,rad,rad);
  //button text
  fill(150,50,50);
  stroke(150,50,50,0.5);
  text("a",X+35,Y1+50);
  fill(50,150,50);
  stroke(50,150,50,0.5);
  text("b",X+35,Y2+50);
  
  //reset
  
  if((mouseX>520)&&(mouseX<520+40)&&(mouseY>200)&&(mouseY <200+215)){
    fill(250);
    stroke(90,90,90,0.5);
    if(mouseIsPressed==true){
      rad=50;
      w=95;
      h=80;
    }
  }
  else{
    fill(210);
    stroke(90,90,90,0.5);
  }
  rect(520,200,40,215);
}
function keyPressed(){
  if((key==='a')&&((mouseX>X)&&(mouseX<X+w)&&(mouseY>Y1)&&(mouseY <Y1+h))){
    w++;
  }
  
  if((key==='b')&&((mouseX>X)&&(mouseX<X+w)&&(mouseY>Y2)&&(mouseY <Y2+h))){
    h++;
  }
}