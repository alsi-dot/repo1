var img1;
var img2;

var quote = "What a sunset...";

function preload() {

	img1 = loadImage("uagheE.jpg");
	img2 = loadImage("uaghe.png");
}


function setup() {

	createCanvas(800, 800);

	textFont("Helvetica");

	fill(255);

	stroke(255);

}


function draw () {

	background(102);

	textSize(48);
	
	image(img1, 0, 0,800,800);
	image(img2, mouseX*-1, mouseY*-1,800,800);
	text(quote, 60, 80, 400, 200);

	
}