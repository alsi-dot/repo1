//////////////////////////////////////////////////
// Object for creation and real-time resize of canvas
const C = {
    loaded: false,
    prop() {return this.height/this.width},
    isLandscape() {return window.innerHeight <= window.innerWidth * this.prop()},
    resize () {
        if (this.isLandscape()) {
          console.log("yes")
            document.getElementById(this.css).style.height = "100%";
            document.getElementById(this.css).style.removeProperty('width');
        } else {
            document.getElementById(this.css).style.removeProperty('height');
            document.getElementById(this.css).style.width = "100%";
        }
    },
    setSize(w,h,p,css) {
        this.width = w, this.height = h, this.pD = p, this.css = css;
    },
    createCanvas() {
        this.main = createCanvas(this.width,this.height,WEBGL), pixelDensity(this.pD), this.main.id(this.css), this.resize();
    }
};
C.setSize(1500,2000,1,'mainCanvas');

function windowResized () {
    C.resize();
}

//////////////////////////////////////////////////


let palette = ["#8D433B", "#AC5535", "#FBCC83", "#fcd300", "#ECA99D", "#A17D54"];

function setup () {
    C.createCanvas();
    angleMode(DEGREES);
    background("#fffceb");
  
    translate(-width/2,-height/2);
  
    // We define the brushes for the hatches, and the brushes for the strokes
    let hatch_brushes = ["marker", "marker2"];
    let stroke_brushes = ["2H", "HB", "charcoal"];
    
    //Flowfields: "zigzag", "seabed", "curved", "truncated"

    // Reset states for next cell
    brush.noStroke();
    brush.noFill();
    brush.noHatch();
       
    brush.set(random(stroke_brushes), random(palette));
    brush.field("zigzag");
    brush.scale(1.5);
    // Set the brush color and draw a line
    brush.stroke(random(palette));
  
  // Set a vector field and draw a flow line
    brush.scale(2.5);
    brush.set(random(stroke_brushes), random(palette));
    brush.field("seabed");
    brush.flowLine(150, 100, 185, 0);
  
    brush.field("truncated");
    brush.set(random(stroke_brushes), random(palette));
    brush.setHatch(random(hatch_brushes), random(palette));
    brush.hatch(random(10,60), random(0,180), {rand: 0, continuous: false, gradient: false});
    brush.scale(1);
    brush.rect(50, 10, 300, 250);
    brush.set(random(stroke_brushes), random(palette));
    brush.noHatch();
    brush.fill(random(palette), 75);
    brush.bleed(random(0.1,0.4));
    brush.circle(100, 150, 75, true);
    
    brush.noField();
    brush.noFill();
    brush.set(random(stroke_brushes), random(palette));
    // Begin defining a custom shape with a specified curvature
    brush.setHatch(random(hatch_brushes), random(palette));
    brush.hatch(random(10,60), random(0,180), {rand: 0, continuous: false, gradient: false});
  
    brush.beginShape(0);
    // Add vertices to the custom shape
    brush.vertex(90, 360);
    brush.vertex(300, 500, 0.5);
    brush.vertex(250, 380);
    // Finish the custom shape and close it with a straight line
    brush.endShape(CLOSE);
    
}